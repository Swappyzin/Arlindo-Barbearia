# Descrição

Arlindo Barbearia é um projeto feito em grupo com o objetivo de melhorar habilidades de Front-end sem nenhum fim lucrativo ou com intenção de roubar layouts e ideias de outros sites oficiais.
O Site está sendo desenvolvido utilizando tecnologias: HTML, CSS e JS(Javascript).